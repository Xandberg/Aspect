# Feldblick als APK

Eine APK ist hier kein neues Programm, sondern eine Hülle: Android startet darin
dieselbe Web-App im Vollbild, ohne Browserleiste, mit eigenem Icon im App-Drawer.
Funktional gewinnst du nichts gegenüber der installierten PWA — aber du kannst die Datei
weitergeben, seitlich installieren oder in den Play Store stellen.

Voraussetzung für alle Wege: Die App liegt bereits unter einer festen HTTPS-Adresse.

## Wichtig vorab: Adresse im Wurzelverzeichnis

Damit die Browserleiste in der APK verschwindet, muss Android die App und die Website
als zusammengehörig erkennen. Dafür liegt eine Datei unter
`https://deine-domain/.well-known/assetlinks.json` — also im **Wurzelverzeichnis** der Domain,
nicht im Unterordner.

Bei GitHub Pages heißt das: Nenne das Repository `DEINNAME.github.io` (genau so), dann
liegt die App unter `https://DEINNAME.github.io/` und du kannst den Ordner `.well-known`
selbst anlegen. Ein Repo namens `feldblick` ergäbe `.../feldblick/` — dort funktioniert
die Verknüpfung nicht.

Ohne diese Datei läuft die APK trotzdem, zeigt aber oben eine schmale Adressleiste.

---

## Weg 1 — PWABuilder (kein Setup, 5 Minuten)

Der einfachste Weg.

1. https://www.pwabuilder.com öffnen, deine Adresse eingeben, *Start*.
2. Bei **Android** auf *Package for stores*.
3. Optionen: Package-ID `de.feldblick.app`, Signing key *Create new*, Häkchen bei
   *Include source code* falls du später selbst weiterbauen willst.
4. Download. Im ZIP liegen:
   - `app-release-signed.apk` → direkt auf dem Handy installierbar
   - `app-release-bundle.aab` → nur für den Play Store
   - `signing.keystore` + `signing-key-info.txt` → **sicher aufbewahren.** Ohne diesen
     Schlüssel kannst du nie wieder ein Update signieren, das über die alte Version drüber geht.
   - `assetlinks.json` → diese Datei in deinem Repo unter `.well-known/assetlinks.json`
     ablegen und veröffentlichen.
5. APK aufs Handy kopieren, öffnen, „Installation aus unbekannter Quelle" bestätigen.

---

## Weg 2 — Bubblewrap (lokal, volle Kontrolle)

Braucht Node.js und ein JDK 17 auf deinem Rechner; das Android SDK lädt Bubblewrap selbst.

```bash
npm install -g @bubblewrap/cli

mkdir feldblick-apk && cd feldblick-apk
bubblewrap init --manifest="https://DEINNAME.github.io/manifest.webmanifest"
# Fragen durchklicken; Package-ID z. B. de.feldblick.app
# Alternativ: die beiliegende twa-manifest.json hier hineinkopieren,
# beide DEINNAME-Platzhalter ersetzen und stattdessen "bubblewrap update" ausführen.

bubblewrap build
```

Ergebnis: `app-release-signed.apk`.

Den Fingerprint für die Verknüpfung holst du dir so:

```bash
keytool -list -v -keystore ./feldblick.keystore -alias feldblick | grep SHA256
```

Den Wert in `assetlinks-vorlage.json` eintragen, Datei als `.well-known/assetlinks.json`
im Web-Repo veröffentlichen, App neu starten — die Adressleiste ist weg.

Updates später: `appVersionCode` in `twa-manifest.json` hochzählen, `bubblewrap build`.
Der eigentliche App-Inhalt aktualisiert sich ohnehin automatisch über den Service Worker,
eine neue APK brauchst du nur bei Icon-, Namens- oder Berechtigungsänderungen.

---

## Weg 3 — Capacitor (echte native App)

Nur nötig, wenn du über den Browser hinauswillst: Aufnahme im Hintergrund, Zugriff auf
den Barometer für eine bessere Höhe, Rohdaten der Satelliten, Foto direkt in die
Galerie schreiben. Das ist kein Verpacken mehr, sondern ein Umbau.

```bash
npm init -y && npm i @capacitor/core @capacitor/android
npx cap init Feldblick de.feldblick.app --web-dir=.
npx cap add android
npx cap open android      # dann in Android Studio bauen
```

Kamera, Standort und Sensoren laufen dann über native Plugins statt über die Web-APIs,
und die Berechtigungen müssen in `AndroidManifest.xml` eingetragen werden. Der Aufwand
lohnt sich vor allem wegen des Barometers: damit werden relative Höhenunterschiede
deutlich genauer als mit GPS allein.

---

## Beiliegende Dateien

- `twa-manifest.json` — fertige Bubblewrap-Konfiguration, zwei Platzhalter ersetzen
- `assetlinks-vorlage.json` — Vorlage für `.well-known/assetlinks.json`
